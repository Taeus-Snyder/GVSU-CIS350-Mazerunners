Placeholder for use-case diagrams folder

Extended use case description is within maze_game_use_cases.md
