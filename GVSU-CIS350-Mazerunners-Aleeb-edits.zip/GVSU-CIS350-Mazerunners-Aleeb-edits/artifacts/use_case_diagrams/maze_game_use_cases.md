![image](https://user-images.githubusercontent.com/112494911/194790491-f7591c4e-a7fd-475e-9742-fc3aa21d7ca8.png)

### Extended Use Case Description:

**Use case:** move

**Actors:** user (initiator), player, enemy

**Description:** User presses key and player moves in corresponding direction. Player will stop moving when User releases key or when Player reaches an immovable object. Enemy moves back and forth in their designated area (system generated). Enemy moves toward Player when Player enters within range. Enemy stops moving when dead.

**Cross references:** FR 1.ii, FR 1.iii, FR 3.v, NFR 1.ii, NFR 3.i, NFR 3.ii, NFR 3.iii 
