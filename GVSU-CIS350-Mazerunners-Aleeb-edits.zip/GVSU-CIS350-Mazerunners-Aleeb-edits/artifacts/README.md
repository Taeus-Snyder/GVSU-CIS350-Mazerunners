Placeholder for artifacts
