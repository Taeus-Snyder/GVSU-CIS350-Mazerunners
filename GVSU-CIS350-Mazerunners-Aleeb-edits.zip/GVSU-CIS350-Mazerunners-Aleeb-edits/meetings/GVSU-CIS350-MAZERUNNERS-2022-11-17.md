Team name: Maze Runners

Members present: Matthias Snyder, Autumn Bertram, Ryan Mansour

Date: 11-17-2022

Time: 10:30am

Discussion points:

- Review what has been done
- Plan for next week


Goals for next week (include responsibilities):

- Upload current code
- Set up in-person meeting for coding: Sunday November 20 4pm
