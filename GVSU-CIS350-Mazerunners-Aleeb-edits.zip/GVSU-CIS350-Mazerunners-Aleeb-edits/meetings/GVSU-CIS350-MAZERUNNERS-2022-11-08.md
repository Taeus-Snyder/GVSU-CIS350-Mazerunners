Team name: Maze Runners

Members present: Matthias Snyder, Autumn Bertram

Date: 11-08-2022

Time: 10:30am

Discussion points:

- check in
- where we are: for each person
- what needs to be done


Goals for next week (include responsibilities):

- get back on track
- finish previous tasks
