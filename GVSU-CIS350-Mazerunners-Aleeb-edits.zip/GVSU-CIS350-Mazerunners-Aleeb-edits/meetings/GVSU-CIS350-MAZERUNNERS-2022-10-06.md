Team name: Mazerunners

Members present: Matthais Snyder, Autumn Bertram, Ryan Mansour

Date: 10/03/2022

Time: 10:10 am

Discussion points: 

* Review of last week's goals
* Homework three - use case diagrams -> plan of attack
  - Will discuss with prof how to divide content for different diagrams
  - Will discuss actual use case diagrams to be done after session
* Timeline for milestones
* How to prep for in-class demo

Goals for next week (include responsibilities)

* Use case diagrams -> everyone
* Rough menu + SRS layout -> Autumn
* UML of classes -> Ryan
* Sketches of in-game layout -> Matthias 
* Add project to project tab -> Matthias

