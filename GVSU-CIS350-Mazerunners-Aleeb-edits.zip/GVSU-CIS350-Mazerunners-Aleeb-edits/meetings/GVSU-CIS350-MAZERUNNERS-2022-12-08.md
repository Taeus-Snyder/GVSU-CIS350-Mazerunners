Team name: Maze Runners

Members present: Matthias Snyder, Autumn Bertram, Ryan Mansour

Date: 12-08-2022

Time: 10:30am

Discussion points:

- what we need for the presentation
- final todos

Goals for today/tomorrow (include responsibilities):

- create presentation slides and upload pdf
- collision: matthias
- placement of powerup/health
- enemy/player health interactions: Ryan
- in-game options (reset game, main menu): Autumn
- GameOver state (either you died or you completed the maze): Autumn/Ryan
