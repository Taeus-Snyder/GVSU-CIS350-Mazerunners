Team name: Mazerunners

Members present:

Date: 10/13/22

Time: 10:00 am

Discussion points:
* Review use-cases, menu, class hierarchy UML, and in-game layout; make necessary changes
* Determine how we will present our WIP to the class
  - Slides [x]
* Review estimated timeline; make necessary changes 
* Discuss how to approach upcoming todos: maze generation demo and in-game displays demo
* Name that game!
* Game concept: collect presents for/as Santa, defeat the grinch -> collect all the presents and fly off to deliver them (END SCENE)
* Creating gandt chart

Goals for next week (include responsibilities):
* Coding: (ongoing)
    - Entity class: move with arrow keys/awsd, have health, attack
    - Maze generation
    - Menu GUI

* Prepare documents for presentation:
    - HUD mock-ups: Matthias
    - Menu images: Autumn
    - Chart for timeline - Gandt: Ryan (testing)
