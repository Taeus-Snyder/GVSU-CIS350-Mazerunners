Team name: Maze Runners

Members present: Matthias Snyder, Autumn Bertram, Ryan Mansour

Date: 12-01-2022

Time: 10:30am

Discussion points:

- Review timeline
- Review progress in code
- What needs to be fixed
- What still needs to be done


Goals for next week (include responsibilities):

- Extract code files for maze generation to better align it with the rest of the code file > Matthias
- Meeting: Sunday @ 4pm (virtual): coding session
- Main task during coding session: get the maze up and running in the main GUI, build and apply maze constraints on the player object, check that maze meets requirements
- Note: neet to review SRS to make sure it meets the assignment requirements (# of requirements)
