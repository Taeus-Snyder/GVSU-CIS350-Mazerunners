## Meeting minutes 9-29-2022

Team name: Mazerunners

Members present: Matthais Snyder, Autumn Bertram, Ryan Mansour

Date: 9/29/2022

Time: 10:30 am

Discussion points: 

- Requirements, dividing by section



Goals for next week (include responsibilities)

Write 5 non-functional and 5 functional requirements for each:
- Matthais -> Menu and displays
- Ryan -> Player mechanics
- Autumn -> Enemies
