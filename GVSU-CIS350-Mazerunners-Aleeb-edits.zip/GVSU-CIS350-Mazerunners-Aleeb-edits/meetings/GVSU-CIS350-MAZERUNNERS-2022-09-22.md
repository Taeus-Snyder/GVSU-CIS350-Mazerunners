## Meeting minutes 9-22-2022

Team name: Mazerunners

Members present: Matthais Snyder, Autumn Bertram, Ryan Mansour

Date: 9/22/2022

Time: 10:00 am

Discussion points: 

- Setting up the proposal
- Defining game mechanics



Goals for next week (include responsibilities)

- Researching how to procedurally generate a maze 
- Figure out how to use GitHub: inserting code and folders 
- Begin sketching classes
