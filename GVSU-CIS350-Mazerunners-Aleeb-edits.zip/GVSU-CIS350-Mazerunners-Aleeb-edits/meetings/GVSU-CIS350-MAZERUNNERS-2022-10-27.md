Team name: Maze Runners

Members present: Matthias Snyder, Autumn Bertram

Date: 10-27-2022

Time: 10:30am

Discussion points:

- Interim assignment
- Reviewing code
- Looking over starting menu GUI
- Current progress with maze generation
- Next steps


Goals for next week (include responsibilities):

- flesh out menu design (color, font, imaging), begin creating in-game displays (health box?): Autumn
- figuring out how to transfer maze logic into java: Matthias
- fleshing out player class: Ryan
