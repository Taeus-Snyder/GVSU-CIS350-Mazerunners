Team name: Maze Runners

Members present: Matthias Snyder, Autumn Bertram, Ryan Mansour

Date: 11-20-2022

Time: 4:00pm

Discussion points:

- coding session
- current status of code
- upload progress: maze logic, health, in-game menu buttons

Goals for next week:

- get the files uploaded > everyone
- continue to fix bugs in the maze logic > Matthias
- Options menu > Autumn
- Player character interactions > Ryan
