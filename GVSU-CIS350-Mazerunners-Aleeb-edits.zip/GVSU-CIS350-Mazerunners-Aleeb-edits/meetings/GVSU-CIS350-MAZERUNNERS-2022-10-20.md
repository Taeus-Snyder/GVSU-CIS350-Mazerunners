Team name: Maze Runners

Members present: Ryan Mansour, Matthias Snyder, Autumn Bertram


Date: 10-20-2022

Time: 10:30am

Discussion points:
- HW 4: dividing responsibilites for tasks
- Choosing feature to display for technical progress
- Using gantt for more tracking tasks

Goals for next week (include responsibilities)
- Menu functionality - Autumn
- Maze generation starting (research, begin fleshing out maze class) - Matthias
- Character class starting (creating base character) - Ryan
