Placeholder for documents folder
